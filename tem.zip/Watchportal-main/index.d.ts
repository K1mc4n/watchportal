/**
 * Initialize a new Farcaster mini app project
 * @returns Promise<void>
 */
export function init(): Promise<void>; 